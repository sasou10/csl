<?php

session_start();

//recuperer les données venant de la page HTML
//mail 	adresse 	typecarte 	numerocarte 	dateexp 	code


$mail = $_SESSION['mail'] ;
$adresse = isset($_POST["adresse"])? $_POST["adresse"] : "";
$typecarte = isset($_POST["typecarte"])? $_POST["typecarte"] : "";
$numerocarte = isset($_POST["numerocarte"])? $_POST["numerocarte"] : "";
$dateexp = isset($_POST["dateexp"])? $_POST["dateexp"] : "";
$code = isset($_POST["code"])? $_POST["code"] : "";

//identifier votre BDD
$database = "projetweb";
//connectez-vous dans votre BDD
//Rappel: votre serveur = localhost et votre login = root et votre password = <rien>
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

if ($_POST["button"]) {
	if ($db_found) {
		
		$sql = "SELECT * FROM acheteurs
            WHERE mail = '$mail'";
			$result = mysqli_query($db_handle, $sql);
			while ($data = mysqli_fetch_assoc($result)) {
				if (($adresse ==  $data['adresse'] )&& ($typecarte ==  $data['typecarte'] )&& ($numerocarte ==  $data['numerocarte'] )
					&& ($dateexp ==  $data['dateexp'] )&& ($code ==  $data['code'] )){
						
						echo "achat confirm�";
					}else {
						echo "Vous avez rentre de mauvaises donnees.</br> 
						Veuillez recommencer.</br> 
						
						Si l'erreur persiste, verifiez vos informations sur l'onglet Votre compte.</br></br>"
						;
						
						
						echo'<html>
						
						<a href="panier.php">Revenir au panier</a>
						
						
						
						
						</html>';
					}
					
				
			}
			
			
		
		echo "mail: " . $mail . "<br>";


	} else {
		echo "Database not found";
	}
}//fermer la connexion
mysqli_close($db_handle);
?>