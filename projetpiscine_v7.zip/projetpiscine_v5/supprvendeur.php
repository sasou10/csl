<?php
//recuperer les données venant de la page HTML
session_start();

$mail = isset($_POST["mailv"])? $_POST["mailv"] : 0;

//identifier votre BDD
$database = "projetweb";
//connectez-vous dans votre BDD
//Rappel: votre serveur = localhost et votre login = root et votre password = <rien>


$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

if ($_POST["button2"]) {

	if ($db_found) { 

			$sql = "SELECT * FROM vendeurs
            INNER JOIN items
            ON vendeurs.mail = items.mail";

            $result = mysqli_query($db_handle, $sql);

            if (mysqli_num_rows($result) != 0) {
            	



			
			$sql = "DELETE FROM vendeurs WHERE mail = '$mail'" ;
			$result = mysqli_query($db_handle, $sql);
			
			$sql = "DELETE FROM utilisateurs WHERE mail = '$mail'";
			$result = mysqli_query($db_handle, $sql);
			echo " Le vendeur est supprimé." . "<br>";
		
		
	}else{
		echo "Database not found";
	}
		
}
//fermer la connexion
mysqli_close($db_handle);

?>