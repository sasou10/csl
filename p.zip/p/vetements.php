<?php
    session_start();
?>

<!DOCTYPE html>
<html>

    <head>
        <title>ECE AMAZON</title>
        <link rel="stylesheet" href="style.css" type="text/css">
        <meta charset="UTF-8">
<style>
            .content{
               background-image:linear-gradient(white, cyan);
                
            }
    </style>
    </head>

    <body>    <!--<div class="header">
        <img src="img/amazon.png" width="20%">
        <h1>ECE AMAZON</h1>
        </div>!-->
        <div class="topnav">

            <ul>  
                   <li><a href="index.php"><img src="img/amazon.png"  width="45px" ></a></li>     
                <li> <div id="cat">Catégories </div>

                <ul>
                    <li><a href="livres.php">livres</a></li>
                    <li><a href="vetements.php">vetements</a></li>
                    <li><a href="musiques.php">musiques</a></li>
                    <li><a href="sports.php">sports</a></li>
                </ul>
                </li>

                <li><a href="ventesflash.php">Ventes Flash</a></li>
                <li><a href="ajoutitem.php">Vendre</a></li>
                <!-- changement de page si util connecté -->
                <?php
                if (isset($_SESSION['mail']) && isset($_SESSION['mdp'])) {
                ?>

                <li><a href="moncompte.php">Votre Compte</a></li>

                <?php
                } else { ?>

                    <li><a href="connexion.php">Votre Compte</a></li>

                 <?php } 
                 ?>    
                <li><a href="admin.php">Admin</a></li>
                <a href="panier.php" style="float:right"><img src="img/panier.png" width="20px" > Panier </a>
            </ul>
        </div>

<div class="content"style="height:800px">

        <p id="popo" style="margin:50px;margin-top:0;"> LISTE D'ARTICLES</p>


<?php

if (isset($_SESSION['mail']) && isset($_SESSION['mdp']) && $_SESSION['categorie'] == "vendeur")
{
    echo "<h3> Vous n'avez pas accès à cette section. <br> Veuillez vous déconnecter ou utiliser un compte acheteur. </h3>";

}

//Accès autre utilisateur
else
{

 //identifier votre BDD
$database = "projetweb";
//connectez-vous dans votre BDD
//Rappel: votre serveur = localhost et votre login = root et votre password = <rien>


$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

if($db_found){

    $sql = "SELECT * FROM items
            INNER JOIN vetements
            ON items.id = vetements.id";

    $result = mysqli_query($db_handle, $sql);
      echo '<div  style="margin:50px;">';
    while ($data = mysqli_fetch_assoc($result)) {
         echo '<div id="registration" style="float:left;margin:30px;width:25%;">';

        
                    echo '<h3>' . utf8_encode($data['nom']) . '</h3><br>';
                    
                    
                   /* echo "id: " . $data['id'] . "<br>";*/
     echo '<div class="photo">';
                    echo "photo: " . $data['photo'] . "<br>";
        echo'</div>';
                   /*echo "description: " . $data['description'] . "<br>";
                    echo "video: " . $data['video'] . "<br>";*/
                    echo "prix: " . $data['prix'] . "€ <br>";
                    echo "quantite: " . $data['quantite'] . "<br>";
                   echo "genre: " . $data['genre'] . "<br>";
                    echo "taille: " . $data['taille'] . "<br>";
                    echo "couleur: " .utf8_encode($data['couleur']) . "<br>";


                    echo '<form action="vetement.php" method="post">
                    <input type="hidden" name="idv1" value="' . $data['id'] . '">
                    <table>
                    <tr>
                    <td colspan="2" align="center"><input type="submit" name="button2" value="Choisir"></td>
                    </tr>
                    </table>
                    </form>';
                    
                    echo "<br>";


                echo'</div>';

                }
   echo'</div>';
}
}


?>

  
        
 </div>
        
        
<div class="footer">
       <h5> © 1996-2019, Amazon.com, Inc. ou ses filiales. </h5>
        </div>
    </body>
</html>
