<!DOCTYPEhtml>
<html>
<head>  
<meta charset="utf-8">
</head>
<body>
<form action="suppritem2.php" method="post">
<table>

<tr>
<td>Id de l'objet à supprimer:</td>
<td><input type="text" name="id"></td>
</tr>

<tr>
<td>Quantité d'objet à supprimer:</td>
<td><input type="text" name="quantite"></td>
</tr>

<tr>
<td>Categorie de l'objet à supprimer:</td>
<td>
<div>
  <input type="radio" id="livre" name="categorie" value="livre">
  <label for="livre">Livre</label>
</div>

<div>
  <input type="radio" id="vetement" name="categorie" value="vetement">
  <label for="vetement">Vetement</label>
</div>

<div>
  <input type="radio" id="musique" name="categorie" value="musique">
  <label for="musique">Musique</label>
</div>

<div>
  <input type="radio" id="sport" name="categorie" value="sport">
  <label for="sport">Sport</label>
</div>

</td>
</tr>

<tr>
<td colspan="2" align="center"><input type="submit" name="button2" value="Supprimer"></td>
</tr>
</table>
</form>
</body>
</html>