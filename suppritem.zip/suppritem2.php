<?php
//recuperer les données venant de la page HTML


$categorie = isset($_POST["categorie"])? $_POST["categorie"] : "";
$quantite = isset($_POST["quantite"])? $_POST["quantite"] : "";
$id = isset($_POST["id"])? $_POST["id"] : 0;
$data=0;
$q2 =0;

//identifier votre BDD
$database = "projetweb";
//connectez-vous dans votre BDD
//Rappel: votre serveur = localhost et votre login = root et votre password = <rien>


$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

if ($_POST["button2"]) {
	if ($db_found) { 
	
	switch ($categorie) {
			case "livre":
			
			$sql = "SELECT quantite FROM items 
			WHERE id = '$id'";
			$q1 = mysqli_query($db_handle, $sql);
			$row = mysqli_fetch_assoc($q1);
			$q2 = $row['quantite'] - $quantite ;
			
		
			
			if($q2 !=0)
			{
				$sql ="UPDATE items
					SET quantite = '$q2'
						WHERE id = '$id'";
				$result = mysqli_query($db_handle, $sql);
				echo "L'article est supprimé." . "<br>";
			} else {
			
			$sql = "DELETE FROM livres WHERE id = '$id'";
			$result = mysqli_query($db_handle, $sql);
			$sql = "DELETE FROM items WHERE id = '$id'";
			$result = mysqli_query($db_handle, $sql);
			echo "L'article est supprimé." . "<br>";
			}
			
			
			 ;
        
			break;
		
			case "vetement":
			
			$sql = "SELECT quantite FROM items 
			WHERE id = '$id'";
			$q1 = mysqli_query($db_handle, $sql);
			$row = mysqli_fetch_assoc($q1);
			$q2 = $row['quantite'] - $quantite ;
			
			
			
			if($q2 !=0)
			{
				$sql ="UPDATE items
					SET quantite = '$q2'
						WHERE id = '$id'";
				$result = mysqli_query($db_handle, $sql);
				echo "L'article est supprimé." . "<br>";
			} else {
			$sql = "DELETE FROM `vetements` WHERE `id` = $id";
			$result = mysqli_query($db_handle, $sql);
			$sql = "DELETE FROM `items` WHERE `id` = $id";
			$result = mysqli_query($db_handle, $sql);
			echo "L'article est supprimé." . "<br>";
			}
			
			
			;
			break;
		
		
			case "musique":
			
			$sql = "SELECT quantite FROM items 
			WHERE id = '$id'";
			$q1 = mysqli_query($db_handle, $sql);
			$row = mysqli_fetch_assoc($q1);
			$q2 = $row['quantite'] - $quantite ;
			
			
			if($q2 !=0)
			{
				$sql ="UPDATE items
					SET quantite = '$q2'
						WHERE id = '$id'";
				$result = mysqli_query($db_handle, $sql);
				echo "L'article est supprimé." . "<br>";
			} else {
			
			$sql = "DELETE FROM `musiques` WHERE `id` = $id";
			$result = mysqli_query($db_handle, $sql);
			$sql = "DELETE FROM `items` WHERE `id` = $id";
			$result = mysqli_query($db_handle, $sql);
			echo "L'article est supprimé." . "<br>";
			}
	
			;
			break;
		
		
		case "sport":
		
		$sql = "SELECT quantite FROM items 
			WHERE id = '$id'";
			$q1 = mysqli_query($db_handle, $sql);
			$row = mysqli_fetch_assoc($q1);
			$q2 = $row['quantite'] - $quantite ;
			
		
			
			if($q2 !=0)
			{
				$sql ="UPDATE items
					SET quantite = '$q2'
						WHERE id = '$id'";
				$result = mysqli_query($db_handle, $sql);
				echo "L'article est supprimé." . "<br>";
			} else {
		
		$sql = "DELETE FROM `sports` WHERE `id` = $id";
			$result = mysqli_query($db_handle, $sql);
			$sql = "DELETE FROM `items` WHERE `id` = $id";
			$result = mysqli_query($db_handle, $sql);
			echo "L'article est supprimé." . "<br>";
			}
        ;
        break;
			}
		
		
	}else{
		echo "Database not found";
	}
		
}
//fermer la connexion
mysqli_close($db_handle);

?>