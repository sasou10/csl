<?php

session_start();
//recuperer les données venant de la page HTML
//mail 	photo 	image

$mail = isset($_POST["mail"])? $_POST["mail"] : "";
$pseudo = isset($_POST["pseudo"])? $_POST["pseudo"] : "";
$nom = isset($_POST["nom"])? $_POST["nom"] : "";
$prenom = isset($_POST["prenom"])? $_POST["prenom"] : "";
$mdp = isset($_POST["mdp"])? $_POST["mdp"] : "";
$photo = isset($_POST["photo"])? $_POST["photo"] : "";
$image = isset($_POST["image"])? $_POST["image"] : "";
$categorie = "vendeur";


//identifier votre BDD
$database = "projetweb";
//connectez-vous dans votre BDD
//Rappel: votre serveur = localhost et votre login = root et votre password = <rien>
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

if ($_POST["button3"]) {
	if ($db_found) {

		$sql = "SELECT * FROM utilisateurs ";
		if ($mail != "") {
			
			$sql .= " WHERE mail LIKE '%$mail%'";
			
		}
		$result = mysqli_query($db_handle, $sql);
		//regarder s'il y a de résultat
		if (mysqli_num_rows($result) != 0) {
			//le mail est déjà dans la BDD
			
			include 'ajoutvendeur.php';
			echo "<script> alert('Un compte a déja été créé avec cette adresse mail.') </script>";
		}

		else {
						
			$sql = "INSERT INTO utilisateurs(mail,pseudo,nom, prenom, mdp, categorie)
			       VALUES('$mail', 'pseudo', '$nom', '$prenom', '$mdp', '$categorie')";
			$result = mysqli_query($db_handle, $sql);


			$sql = "INSERT INTO vendeurs(mail,photo,image)
			       VALUES('$mail', '$photo', '$image')";
			$result = mysqli_query($db_handle, $sql);

			echo "Add successful." . "<br>";
			//
			$sql = "SELECT * FROM utilisateurs INNER JOIN vendeurs ON utilisateurs.mail = vendeurs.mail WHERE mail LIKE '%$mail%' ";
			// if ($mail != "") {
			// 	//on cherche le livre avec les paramètres titre et auteur
			// 	$sql .= " WHERE mail LIKE '%$mail%'";
			// }
			$result = mysqli_query($db_handle, $sql);

			//Ne rentre pas dans la boucle
		while ($data = mysqli_fetch_assoc($result)) {
			
				echo "Vous avez bien inscrit le vendeur :" . "<br>";
				
				echo "nom: " . $data['nom'] . "<br>";
				echo "prenom: " . $data['prenom'] . "<br>";
				echo "photo: " . $data['photo'] . "<br>";
				echo "<br>";
			}
			


		}
	} else {
		echo "Database not found";
	}
}//fermer la connexion
mysqli_close($db_handle);
?>