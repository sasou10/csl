<?php
//recuperer les données venant de la page HTML
session_start();

$mail = isset($_POST["mailv"])? $_POST["mailv"] : 0;

//identifier votre BDD
$database = "projetweb";
//connectez-vous dans votre BDD
//Rappel: votre serveur = localhost et votre login = root et votre password = <rien>


$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

if ($_POST["button2"]) {

	if ($db_found) { 

			$sql = "SELECT * FROM vendeurs
            INNER JOIN items
            ON vendeurs.mail = items.mail";

            $result = mysqli_query($db_handle, $sql);

            if (mysqli_num_rows($result) != 0) {
            	//Marche mais donne un erreur
            while ($data = mysqli_fetch_assoc($result)) {

			$categorie = $data['categorie'];

            switch ($categorie) {
			case "livre":

				///Supression des items
            	$sql = "DELETE FROM livres INNER JOIN items ON items.id = livres.id WHERE items.mail = '$mail'";
				$result = mysqli_query($db_handle, $sql);
				$sql = "DELETE FROM items WHERE mail = '$mail'";
				$result = mysqli_query($db_handle, $sql);
				//echo "L'article est supprimé." . "<br>";

				$sql = "DELETE FROM vendeurs WHERE mail = '$mail'" ;
				$result = mysqli_query($db_handle, $sql);
			
				$sql = "DELETE FROM utilisateurs WHERE mail = '$mail'";
				$result = mysqli_query($db_handle, $sql);
				echo " Le vendeur est supprimé." . "<br>";

				break;

			case "musique":

				///Supression des items
            	$sql = "DELETE FROM musiques INNER JOIN items ON items.id = musiques.id WHERE items.mail = '$mail'";
				$result = mysqli_query($db_handle, $sql);
				$sql = "DELETE FROM items WHERE mail = '$mail'";
				$result = mysqli_query($db_handle, $sql);
				//echo "L'article est supprimé." . "<br>";

				$sql = "DELETE FROM vendeurs WHERE mail = '$mail'" ;
				$result = mysqli_query($db_handle, $sql);
			
				$sql = "DELETE FROM utilisateurs WHERE mail = '$mail'";
				$result = mysqli_query($db_handle, $sql);
				echo " Le vendeur est supprimé." . "<br>";

				break;

			case "sport":

				///Supression des items
            	$sql = "DELETE FROM sports INNER JOIN items ON items.id = sports.id WHERE items.mail = '$mail'";
				$result = mysqli_query($db_handle, $sql);
				$sql = "DELETE FROM items WHERE mail = '$mail'";
				$result = mysqli_query($db_handle, $sql);
				//echo "L'article est supprimé." . "<br>";

				$sql = "DELETE FROM vendeurs WHERE mail = '$mail'" ;
				$result = mysqli_query($db_handle, $sql);
			
				$sql = "DELETE FROM utilisateurs WHERE mail = '$mail'";
				$result = mysqli_query($db_handle, $sql);
				echo " Le vendeur est supprimé." . "<br>";

				break;

			case "vetement":

				///Supression des items
            	$sql = "DELETE FROM vetements INNER JOIN items ON items.id = vetements.id WHERE items.mail = '$mail'";
				$result = mysqli_query($db_handle, $sql);
				$sql = "DELETE FROM items WHERE mail = '$mail'";
				$result = mysqli_query($db_handle, $sql);
				//echo "L'article est supprimé." . "<br>";

				$sql = "DELETE FROM vendeurs WHERE mail = '$mail'" ;
				$result = mysqli_query($db_handle, $sql);
			
				$sql = "DELETE FROM utilisateurs WHERE mail = '$mail'";
				$result = mysqli_query($db_handle, $sql);
				echo " Le vendeur est supprimé." . "<br>";

				break;            	


			}
		}
	}
			
		
		
	}else{
		echo "Database not found";
	}
		
}
//fermer la connexion
mysqli_close($db_handle);


?>