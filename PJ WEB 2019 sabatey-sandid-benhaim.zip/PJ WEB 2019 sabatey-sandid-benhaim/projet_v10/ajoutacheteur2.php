<?php
    session_start();
?>

<!DOCTYPE html>
<html>

    <head>
        <title> Administrateur </title>
        <link rel="stylesheet" href="style.css" type="text/css">
        <meta charset="UTF-8">
<style>
            .content{
               background-image:linear-gradient(white, pink);
                
            }
        </style>
    </head>

    <body>    

        <div class="topnav">

            <ul>  
                   <li><a href="index.php"><img src="img/amazon.png"  width="45px" ></a></li>     
                <li> <div id="cat">Catégories </div>

                <ul>
                    <li><a href="livres.php">livres</a></li>
                    <li><a href="vetements.php">vetements</a></li>
                    <li><a href="musiques.php">musiques</a></li>
                    <li><a href="sports.php">sports</a></li>
                </ul>
                </li>

                <li><a href="ventesflash.php">Ventes Flash</a></li>
                <li><a href="ajoutitem.php">Vendre</a></li>
                
                  <!-- changement de page si util connecté -->
                <?php
                if (isset($_SESSION['mail']) && isset($_SESSION['mdp'])) {
                ?>

                <li><a href="moncompte.php">Votre Compte</a></li>

                <?php
                } else { ?>

                    <li><a href="connexion.php">Votre Compte</a></li>

                 <?php } 
                 ?>  

                 <?php
                
                if (isset($_SESSION['mail']) && isset($_SESSION['mdp']) && $_SESSION['categorie'] == "admin") {
                ?>

                <li><a href="admin3.php">Admin</a></li>

                <?php
                } else { ?>

                    <li><a href="admin.php">Admin</a></li>

                 <?php } 
                 ?>    

                
                <a href="panier.php" style="float:right"><img src="img/panier.png" width="20px" > Panier </a>
            </ul>
        </div>

<div class="content" align="center" style="height:1000px">

<?php
//recuperer les données venant de la page HTML
//mail 	adresse 	typecarte 	numerocarte 	dateexp 	code


$mail = isset($_POST["maila"])? $_POST["maila"] : "";
$adresse = isset($_POST["adresse"])? $_POST["adresse"] : "";
$typecarte = isset($_POST["typecarte"])? $_POST["typecarte"] : "";
$numerocarte = isset($_POST["numerocarte"])? $_POST["numerocarte"] : "";
$dateexp = isset($_POST["dateexp"])? $_POST["dateexp"] : "";
$code = isset($_POST["code"])? $_POST["code"] : "";

//identifier votre BDD
$database = "projetweb";
//connectez-vous dans votre BDD
//Rappel: votre serveur = localhost et votre login = root et votre password = <rien>
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

if ($_POST["button2"]) {
	if ($db_found) {
		$sql = "SELECT * FROM acheteurs";
		if ($mail != "") {
			
			$sql .= " WHERE mail LIKE '%$mail%'";
			
		}
		$result = mysqli_query($db_handle, $sql);
		//regarder s'il y a de résultat
		if (mysqli_num_rows($result) != 0) {
			//le mail est déjà dans la BDD
			echo "Un compte a déja été créé avec cette adresse mail.";
		} else {
						
			$sql = "INSERT INTO acheteurs(mail,adresse,typecarte,numerocarte,dateexp,code)
			       VALUES('$mail', '$adresse', '$typecarte', '$numerocarte', '$dateexp','$code')";
			$result = mysqli_query($db_handle, $sql);
			echo "Add successful." . "<br>";
			//on affiche le livre ajouté
			$sql = "SELECT * FROM acheteurs";
			if ($mail != "") {
				//on cherche le livre avec les paramètres titre et auteur
				$sql .= " WHERE mail LIKE '%$mail%'";
			}
			$result = mysqli_query($db_handle, $sql);
			while ($data = mysqli_fetch_assoc($result)) {
				echo "Vos informations personnelles:" . "<br>";
				
				echo "mail: " . $data['mail'] . "<br>";
				echo "adresse: " . $data['adresse'] . "<br>";
				echo "typecarte: " . $data['typecarte'] . "<br>";
				echo "numerocarte: " . $data['numerocarte'] . "<br>";
				echo "dateexp: " . $data['dateexp'] . "<br>";
				echo "code: " . $data['code'] . "<br>";
				echo "<br>";

				session_start();
		$_SESSION['adresse'] = $_POST['adresse'];
        $_SESSION['typecarte'] = $_POST['typecarte'];
        $_SESSION['numerocarte'] = $_POST['numerocarte'];
        $_SESSION['dateexp'] = $_POST['dateexp'];
        $_SESSION['code'] = $_POST['code'];

			}


        /// Connexion à la session de l'acheteur
        
        
		}

		header('location: moncompte.php');

	} else {
		echo "Database not found";
	}
}//fermer la connexion
mysqli_close($db_handle);
?>

   
        </div>
        
        
<div class="footer">
       <h5> © 1996-2019, Amazon.com, Inc. ou ses filiales. </h5>
        </div>
    </body>
</html>