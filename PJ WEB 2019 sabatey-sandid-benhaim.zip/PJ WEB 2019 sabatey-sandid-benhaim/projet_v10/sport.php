<?php
    session_start();
?>

<!DOCTYPE html>
<html>

    <head>
        <title>ECE AMAZON</title>
        <link rel="stylesheet" href="style.css" type="text/css">
        <meta charset="UTF-8">
<style>
            .content{
               background-image:linear-gradient(white, lightblue);
                
            }
        </style>
    </head>

    <body>    <!--<div class="header">
        <img src="img/amazon.png" width="20%">
        <h1>ECE AMAZON</h1>
        </div>!-->
        <div class="topnav">

            <ul>  
                   <li><a href="index.php"><img src="img/amazon.png"  width="45px" ></a></li>     
                <li> <div id="cat">Catégories </div>

                <ul>
                    <li><a href="livres.php">livres</a></li>
                    <li><a href="vetements.php">vetements</a></li>
                    <li><a href="musiques.php">musiques</a></li>
                    <li><a href="sports.php">sports</a></li>
                </ul>
                </li>

                <li><a href="ventesflash.html">Ventes Flash</a></li>
                <li><a href="ajoutitem.php">Vendre</a></li>
                <!-- changement de page si util connecté -->
                <?php
                if (isset($_SESSION['mail']) && isset($_SESSION['mdp'])) {
                ?>

                <li><a href="moncompte.php">Votre Compte</a></li>

                <?php
                } else { ?>

                    <li><a href="connexion.php">Votre Compte</a></li>

                 <?php } 
                 ?> 

                 <?php
                
                if (isset($_SESSION['mail']) && isset($_SESSION['mdp']) && $_SESSION['categorie'] == "admin") {
                ?>

                <li><a href="admin3.php">Admin</a></li>

                <?php
                } else { ?>

                    <li><a href="admin.php">Admin</a></li>

                 <?php } 
                 ?>         
                
                <a href="panier.php" style="float:right"><img src="img/panier.png" width="20px" > Panier </a>
            </ul>
        </div>

<div class="content" style="height:850px">
       

<!DOCTYPE html>
<?php

if (isset($_SESSION['mail']) && isset($_SESSION['mdp']) && $_SESSION['categorie'] == "admin")
{

    $id = isset($_POST["ids1"])? $_POST["ids1"] : 0;


//identifier votre BDD
    $database = "projetweb";
    //connectez-vous dans votre BDD
    //Rappel: votre serveur = localhost et votre login = root et votre password = <rien>
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database);
        
        if ($db_found) {

            $sql = "SELECT * FROM items
            INNER JOIN sports
            ON items.id = sports.id";

            $result = mysqli_query($db_handle, $sql);

            if (mysqli_num_rows($result) != 0) {

            $sql = "SELECT * FROM items
            INNER JOIN sports
            ON items.id = sports.id
            WHERE sports.id = '$id'";


            $result = mysqli_query($db_handle, $sql);

    
        while ($data = mysqli_fetch_assoc($result)) {
                     echo '<p id="popo" style="margin-top:0;" >';
                    echo utf8_encode($data['nom']);
                    echo'</p>';
             echo '<div class="alinea">';
                    echo "id: " . $data['id'] . "<br>";
              echo '<div  class="it">' ;
                    echo "<img src='img/" . $data['photo'] . "'><br><br>";
            echo'</div>';
             echo'</div>';
                  echo '<div class="titre">';

            
                    echo "<i>" . utf8_encode($data['categorie']) . "</i><br>";
             echo'</div>';
                    echo '<div style="margin:50px">';
                    echo "Description: " .  utf8_encode($data['description']) . "<br>";
                    echo'</div>';
            
                    echo "video: " . $data['video'] . "<br> <br>";
            echo '<div class="alinea">';
                    echo "prix: " . $data['prix'] . " € <br>";
                    echo "quantite: " . $data['quantite'] . "<br>";
                    echo "</div>";
            
                   

                    echo "<br>";
                    
                    echo '
                    <form action="suppritem.php" method="post">
                    <input type="hidden" name="id1" value="' . $data['id'] . '">
                    
                    <table>
                    <tr>
                    <td>Quantite à supprimer:</td>
                    <td><input type="number" name="quantite1"></td>
                    </tr>
                    <tr>
                    <td colspan="2" align="center"><input type="submit" name="button1" value="Supprimer"></td>
                    </tr>
                    </table>
                    </form>';
                    
                    echo "<br>";
                }
            }

        
    }


}
else {

$id = isset($_POST["ids1"])? $_POST["ids1"] : 0;


//identifier votre BDD
    $database = "projetweb";
    //connectez-vous dans votre BDD
    //Rappel: votre serveur = localhost et votre login = root et votre password = <rien>
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database);
        
        if ($db_found) {

            $sql = "SELECT * FROM items
            INNER JOIN sports
            ON items.id = sports.id";

            $result = mysqli_query($db_handle, $sql);

            if (mysqli_num_rows($result) != 0) {

            $sql = "SELECT * FROM items
            INNER JOIN sports
            ON items.id = sports.id
            WHERE sports.id = '$id'";


            $result = mysqli_query($db_handle, $sql);

    
        while ($data = mysqli_fetch_assoc($result)) {
                    
                    echo '<p id="popo" style="margin-top:0;" >';
                    echo utf8_encode($data['nom']);
                    echo'</p>';
             echo '<div class="alinea">';
                    echo "id: " . $data['id'] . "<br>";
                    echo '<div  class="it">' ;
                    echo "<img src='img/" . $data['photo'] . "'><br><br>";
            echo'</div>';
             echo'</div>';
                  echo '<div class="titre">';
             
            
                    echo "<i>" . utf8_encode($data['categorie']) . "</i><br>";
             echo'</div>';
                    echo '<div style="margin:50px">';
                    echo "Description: " .  utf8_encode($data['description']) . "<br>";
                    echo'</div>';
            
                    echo "video: " . $data['video'] . "<br> <br>";
            echo '<div class="alinea">';
                    echo "prix: " . $data['prix'] . " € <br>";
                    echo "quantite: " . $data['quantite'] . "<br>";
                    echo "</div>";
            
            
                    echo "<br>";
					
					echo '
                    <form id="registration" action="ajoutpanier.php" method="post" style="float:left">
                    <input type="hidden" name="idp" value="' . $data['id'] . '">
                    
                    <table>
                    <tr>
                    <td>Quantite à acheter:</td>
                    <td><input type="number" name="quantitep"></td>
                    </tr>
                    <tr>
                    <td colspan="2" align="center"><input type="submit" name="buttonp" value="Ajouter au panier"></td>
                    </tr>
                    </table>
                    </form>';
                    
                    echo "<br>";
                }
            }

        
    }
    }



?>
   
        
 </div>
        
        
<div class="footer">
       <h5> © 1996-2019, Amazon.com, Inc. ou ses filiales. </h5>
        </div>
    </body>
</html>