<?php
//recuperer les données venant de la page HTML

session_start();



//identifier votre BDD
$database = "projetweb";
//connectez-vous dans votre BDD
//Rappel: votre serveur = localhost et votre login = root et votre password = <rien>


$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);


if ($_POST["button"]) {
	if ($db_found) { 
	
	
	 if (isset($_SESSION['mail']) && isset($_SESSION['mdp'])) {
                
                echo '<html>          
    <head>
        <title> Informations de paiement ! </title>
        <link rel="stylesheet" href="style.css" type="text/css">
        <meta charset="utf-8">
    </head>
    <body>
        <div class="topnav">

            <ul>  
                <li><a href="index.php"><img src="img/amazon.png"  width="45px" ></a></li>     
                <li> <div id="cat">Catégories </div>

                    <ul>
                        <li><a href="livres.php">livres</a></li>
                        <li><a href="vetements.php">vetements</a></li>
                        <li><a href="musiques.php">musiques</a></li>
                        <li><a href="sports.php">sports</a></li>
                    </ul>
                </li>

                <li><a href="ventesflash.php">Ventes Flash</a></li>
                <li><a href="ajoutitem.php">Vendre</a></li>';

                if (isset($_SESSION['mail']) && isset($_SESSION['mdp'])) {

                echo '<li><a href="moncompte.php">Votre Compte</a></li>';
                
                } else {

                    echo '<li><a href="connexion.php">Votre Compte</a></li>';

                } 
                                 
                if (isset($_SESSION['mail']) && isset($_SESSION['mdp']) && $_SESSION['categorie'] == "admin") {
           

                echo '<li><a href="admin3.php">Admin</a></li>';

               
                } else {

                    echo '<li><a href="admin.php">Admin</a></li>';
                }
  
                
           echo     '<a href="panier.php" style="float:right"><img src="img/panier.png" width="20px" > Panier </a>
            </ul>
        </div>
        <div class="content">
		
            <p > Informations de paiement  </p>
            <img class="iconn" src="img/conn.png">
            <form action="verif3.php" method="post">
                <table>
                    
                    <tr>
                        <td>Adresse:</td>
                        <td><input type="text" name="adresse" placeholder="37 Quai de Grenelle"></td>
                    </tr>
                    <tr>
                        
                        <td>Type de carte:</td>
                        <td>
                            <input style="width:20%" type="radio" name="card" value="mastercard" ><img src="image1.png"  width="10%">
                    <input style="width:20%" type="radio" name="card" value="visa" ><img src="image2.png"  width="10%"></td>
                       <!-- 
                            <input style="width:20%" type="image" name="mastercard" value="image1" src="image1.png" >
      <input type="radio" name="mastercard" value="image2" id="image2"> <label for="image2"><img src="image2.png"  width="10%"></label><br>!-->
                        
                    </tr>
                    <tr>
                        <td >numero de carte:</td>
                        <td><input type="number" name="numerocarte"></td>
                    </tr>
                    <tr>
                        <td>date expiration:</td>
                        <td><input type="month" name="dateexp" placeholder="avril/2019"></td>
                    </tr>
                    <tr>
                        <td> Security code:</td>
                        <td><input type="number" name="code" placeholder="inscris au dos de la carte"></td>
                    </tr>
                    <tr>
                        <td colspan="2" align="center"> <input type="submit" name="button" value="Valider !"></td>
                    </tr>
                </table>
            </form>
        </div>
        <div class="footer">
       <h5> © 1996-2019, Amazon.com, Inc. ou ses filiales. </h5>
        </div>
    </body>
</html>' ; 
				
				
				
				
				
	 }	else {
		 
		 
		 echo '<html>          
    <head>
        <title> Informations de paiement ! </title>
        <link rel="stylesheet" href="style.css" type="text/css">
        <meta charset="utf-8">
    </head>
    <body>
        <div class="topnav">

            <ul>  
                <li><a href="index.php"><img src="img/amazon.png"  width="45px" ></a></li>     
                <li> <div id="cat">Catégories </div>

                    <ul>
                        <li><a href="livres.php">livres</a></li>
                        <li><a href="vetements.php">vetements</a></li>
                        <li><a href="musiques.php">musiques</a></li>
                        <li><a href="sports.php">sports</a></li>
                    </ul>
                </li>

                <li><a href="ventesflash.php">Ventes Flash</a></li>
                <li><a href="ajoutitem.php">Vendre</a></li>';

                  if (isset($_SESSION['mail']) && isset($_SESSION['mdp'])) {

                echo '<li><a href="moncompte.php">Votre Compte</a></li>';
                
                } else {

                    echo '<li><a href="connexion.php">Votre Compte</a></li>';

                } 
                                 
                if (isset($_SESSION['mail']) && isset($_SESSION['mdp']) && $_SESSION['categorie'] == "admin") {
           

                echo '<li><a href="admin3.php">Admin</a></li>';

               
                } else {

                    echo '<li><a href="admin.php">Admin</a></li>';
                }
  

                echo
                '<a href="panier.php" style="float:right"><img src="img/panier.png" width="20px" > Panier </a>
            </ul>
        </div>
		<div class="content">
		
            <p >  Veuiller vous connecter pour acceder à cette page </br>
			<li><a href="connexion.php">Connexion</a></li></p>
			</div>
        <div class="footer">
       <h5> © 1996-2019, Amazon.com, Inc. ou ses filiales. </h5>
        </div>
    </body>
</html>';
	 }
		
	}else{
		echo "Database not found";
	}
	
		
}
//fermer la connexion
mysqli_close($db_handle);

?>
		



